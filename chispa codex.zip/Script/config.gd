extends Node
const GROQ_API_KEY   := "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"
