# terminal_codigo.gd
# Nodo: CanvasLayer (hijo de un StaticBody2D igual que TerminalUI)
# Terminal donde el jugador completa código C# con blancos.
# La IA valida si la respuesta es lógicamente correcta.
#
# Árbol de nodos:
# TerminalCodigo (CanvasLayer)
# └── Panel
#     ├── TituloLabel    (Label)        ← "> COMPLETAR CÓDIGO"
#     ├── InstruccionLabel (Label)      ← "Escribe lo que falta en el ___"
#     ├── CodigoLabel    (RichTextLabel)← muestra el código con ___
#     ├── InputField     (LineEdit)     ← el jugador escribe aquí
#     ├── ValidarBtn     (Button)       ← "Validar"
#     ├── FeedbackLabel  (Label)        ← resultado
#     └── CerrarBtn      (Button)       ← "Cerrar"

extends CanvasLayer

signal respuesta_correcta
signal respuesta_incorrecta

const PANEL_SIZE := Vector2(580, 420)

# ── Banco de ejercicios locales (fallback si la IA falla) ─────────────────────
const EJERCICIOS := [
	{
		"instruccion": "Define la clase correctamente:",
		"codigo": "___ Personaje\n{\n    public string nombre;\n    public int vida;\n}",
		"respuesta_esperada": "class",
		"concepto": "clase"
	},
	{
		"instruccion": "Crea un objeto de la clase Personaje:",
		"codigo": "Personaje heroe = ___ Personaje();",
		"respuesta_esperada": "new",
		"concepto": "instancia"
	},
	{
		"instruccion": "Define un método que no retorna nada:",
		"codigo": "___ void Atacar()\n{\n    Console.WriteLine(\"Atacando!\");\n}",
		"respuesta_esperada": "public",
		"concepto": "método"
	},
	{
		"instruccion": "Encapsula el atributo con una propiedad privada:",
		"codigo": "___ int _vida;\n\npublic int Vida\n{\n    get { return _vida; }\n}",
		"respuesta_esperada": "private",
		"concepto": "encapsulamiento"
	},
	{
		"instruccion": "El constructor tiene el mismo nombre que la ___:",
		"codigo": "class Enemigo\n{\n    public Enemigo()\n    {\n        // constructor\n    }\n}",
		"respuesta_esperada": "clase",
		"concepto": "constructor"
	},
	{
		"instruccion": "Hereda de la clase base Animal:",
		"codigo": "class Perro ___ Animal\n{\n    public void Ladrar() { }\n}",
		"respuesta_esperada": ":",
		"concepto": "herencia"
	},
	{
		"instruccion": "Declara una lista de objetos Enemigo:",
		"codigo": "___ enemigos = new List<Enemigo>();",
		"respuesta_esperada": "List<Enemigo>",
		"concepto": "colecciones"
	},
]

# ── Nodos ─────────────────────────────────────────────────────────────────────
@onready var _panel           : Panel         = $Panel
@onready var _instruccion     : Label         = $Panel/InstruccionLabel
@onready var _codigo_label    : RichTextLabel = $Panel/CodigoLabel
@onready var _input           : LineEdit      = $Panel/InputField
@onready var _validar_btn     : Button        = $Panel/ValidarBtn
@onready var _feedback_label  : Label         = $Panel/FeedbackLabel
@onready var _cerrar_btn      : Button        = $Panel/CerrarBtn

# ── Estado ────────────────────────────────────────────────────────────────────
var _ejercicio_actual := {}
var _validando        := false
var _resuelta         := false

# ── Ciclo de vida ─────────────────────────────────────────────────────────────
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_centrar_panel()
	_validar_btn.pressed.connect(_on_validar)
	_cerrar_btn.pressed.connect(_cerrar)
	_input.text_submitted.connect(_on_texto_enviado)

func _centrar_panel() -> void:
	var screen_size := get_viewport().get_visible_rect().size
	_panel.set_deferred("position", (screen_size - PANEL_SIZE) / 2)
	_panel.set_deferred("size", PANEL_SIZE)

func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		_cerrar()
		get_viewport().set_input_as_handled()

# ── API pública ───────────────────────────────────────────────────────────────
func abrir() -> void:
	if _resuelta:
		return
	_resuelta = false
	_validando = false
	_feedback_label.text = ""
	_input.text = ""
	_input.editable = true
	_validar_btn.disabled = false

	# Cargar ejercicio aleatorio
	_ejercicio_actual = EJERCICIOS[randi() % EJERCICIOS.size()]
	_instruccion.text = _ejercicio_actual["instruccion"]

	# Mostrar código con ___ resaltado
	var codigo : String = _ejercicio_actual["codigo"]
	_codigo_label.text = "[color=white]" + codigo.replace(
		"___", "[color=yellow][b]___[/b][/color]"
	) + "[/color]"

	visible = true
	get_tree().paused = true
	_input.grab_focus()

# ── Validación ────────────────────────────────────────────────────────────────
func _on_texto_enviado(_texto: String) -> void:
	_on_validar()

func _on_validar() -> void:
	if _validando:
		return
	var respuesta := _input.text.strip_edges()
	if respuesta.is_empty():
		_feedback_label.text = "Escribe algo primero..."
		return

	_validando = true
	_validar_btn.disabled = true
	_feedback_label.text = "Consultando al sistema..."

	# Pedir a la IA que valide
	_validar_con_ia(respuesta)

func _validar_con_ia(respuesta: String) -> void:
	var ejercicio  : String = _ejercicio_actual["codigo"]
	var concepto   : String = _ejercicio_actual["concepto"]
	var esperada   : String = _ejercicio_actual["respuesta_esperada"]

	var prompt := """Eres un validador de ejercicios de C# sobre POO para principiantes.

Ejercicio: completar el código C# llenando el espacio en blanco (___).
Concepto evaluado: %s
Código: %s
Respuesta esperada: "%s"
Respuesta del estudiante: "%s"

¿Es la respuesta del estudiante correcta o equivalente lógicamente?
Responde ÚNICAMENTE con este JSON, sin markdown:
{"correcto": true, "explicacion": "Explicación breve en español de máximo 15 palabras"}

Si hay variantes válidas (mayúsculas/minúsculas, espacios), considéralas correctas.""" % [concepto, ejercicio, esperada, respuesta]

	# Crear HTTPRequest temporal para la validación
	var http := HTTPRequest.new()
	http.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(http)

	var headers := [
		"Content-Type: application/json",
		"Authorization: Bearer " + Config.GROQ_API_KEY
	]
	var body := JSON.stringify({
		"model": "llama-3.1-8b-instant",
		"messages": [{"role": "user", "content": prompt}],
		"temperature": 0.1,
		"max_tokens": 100
	})

	http.request_completed.connect(
		func(result, code, _h, response_body):
			_on_validacion_lista(result, code, response_body, respuesta, http)
	)
	http.request(
		"https://api.groq.com/openai/v1/chat/completions",
		headers, HTTPClient.METHOD_POST, body
	)

func _on_validacion_lista(result: int, code: int, body: PackedByteArray, respuesta: String, http: HTTPRequest) -> void:
	http.queue_free()
	_validando = false

	# Si la IA falla, usar comparación local como fallback
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		_validar_local(respuesta)
		return

	var texto     := body.get_string_from_utf8()
	var json_resp  = JSON.parse_string(texto)

	if not json_resp:
		_validar_local(respuesta)
		return

	var contenido : String = json_resp["choices"][0]["message"]["content"]
	contenido = contenido.strip_edges().replace("```json","").replace("```","").strip_edges()

	var datos = JSON.parse_string(contenido)
	if not datos or not datos.has("correcto"):
		_validar_local(respuesta)
		return

	var correcto     : bool   = datos["correcto"]
	var explicacion  : String = datos.get("explicacion", "")
	_mostrar_resultado(correcto, explicacion)

func _validar_local(respuesta: String) -> void:
	# Fallback: comparación simple ignorando mayúsculas y espacios
	var esperada  : String = (_ejercicio_actual["respuesta_esperada"] as String).strip_edges().to_lower()
	var dada      : String = respuesta.strip_edges().to_lower()
	var correcto  : bool   = (dada == esperada)
	_mostrar_resultado(correcto, "Respuesta esperada: " + _ejercicio_actual["respuesta_esperada"])

func _mostrar_resultado(correcto: bool, explicacion: String) -> void:
	_validar_btn.disabled = false
	if correcto:
		_feedback_label.text = "✓ Correcto. " + explicacion
		_feedback_label.add_theme_color_override("font_color", Color.GREEN)
		_input.editable = false
		_validar_btn.disabled = true
		_resuelta = true
		await get_tree().create_timer(1.5).timeout
		_cerrar()
		respuesta_correcta.emit()
	else:
		_feedback_label.text = "✗ Incorrecto. " + explicacion
		_feedback_label.add_theme_color_override("font_color", Color.RED)
		_input.text = ""
		_input.grab_focus()
		respuesta_incorrecta.emit()

func _cerrar() -> void:
	visible = false
	get_tree().paused = false
