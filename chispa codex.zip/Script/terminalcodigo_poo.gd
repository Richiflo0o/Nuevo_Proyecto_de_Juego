extends StaticBody2D
@onready var terminal_codigo = $TerminalCodigo

func interactuar() -> void:
	terminal_codigo.abrir()
